const menuPages = [
  {
    name: "About BBTS",
    path: "",
  },
  {
    name: "Administration",
    path: "",
  },
  {
    name: "Resources",
    children: [
      {
        name: "Option A",
        path: "",
      },
      {
        name: "Option B",
        path: "",
      },
      {
        name: "Option C",
        path: "",
      },
      {
        name: "Option D",
        path: "",
      },
      {
        name: "Option E",
        path: "",
      },
    ],
  },
  {
    name: "News & Events",
    path: "",
  },
  {
    name: "Reports",
    path: "",
  },
  {
    name: "Contact Support",
    path: "",
  },
];

export default menuPages;