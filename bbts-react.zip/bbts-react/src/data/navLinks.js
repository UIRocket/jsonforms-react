const navLinks = [
  {
    name: "Processing",
    directChildren: [
      // Batching
      {
        name: "Batching",
        grandChildren: [
          {
            name: "Standard",
          },
          {
            name: "1040X",
            children: [
              {
                name: "Batch Creation",
                path: "/batch-creation",
              },
              {
                name: "Batch Delete/Restore",
                path: "/batch-delete",
              },
              {
                name: "Batch Release",
                path: "/batch-release",
              },
              {
                name: "Batch Rollback",
                path: "/batch-rollback",
              },
              {
                name: "Transmittal Reprint",
                path: "/transmittal-reprint",
              },
              {
                name: "Volume Change",
                path: "/volume-change",
              },
            ],
          },
          {
            name: "Entity",
          },
          {
            name: "ICT",
          },
        ],
      },
      // Non-Batching
      {
        name: "Non-Batching",
        grandChildren: [
          {
            name: "Standard",
          },
          {
            name: "1040X",
            children: [
              {
                name: "Batch Creation",
                path: "batch-creation",
              },
              {
                name: "Batch Delete/Restore",
                path: "batch-delete",
              },
              {
                name: "Batch Release",
                path: "batch-release",
              },
              {
                name: "Batch Rollback",
                path: "batch-rollback",
              },
              {
                name: "Transmittal Reprint",
                path: "transmittal-reprint",
              },
              {
                name: "Volume Change",
                path: "volume-change",
              },
            ],
          },
          {
            name: "Entity",
          },
          {
            name: "ICT",
          },
        ],
      },
    ],
  },
  {
    name: "Maintenance",
    grandChildren: [
      {
        name: "Standard",
      },
      {
        name: "1040X",
      },
      {
        name: "Entity",
      },
      {
        name: "ICT",
        children: [
          {
            name: "Batch Deletion",
            path: "batch-deletion",
          },
          {
            name: "Batch Description Maintenance",
            path: "batch-description-maintenance",
          },
          {
            name: "Program Batch Description Xref",
            path: "program-batch-description-xref",
          },
          {
            name: "Program Code Maintenance",
            path: "Program-code-maintenance",
          },
          {
            name: "Route Maintenance",
            path: "Route Maintenance",
          },
          {
            name: "User Maintenance",
            path: "User Maintenance",
          },
        ],
      },
    ],
  },
  {
    name: "Adjustments",
    children: [
      {
        name: "Batch Profile Adjustment Log",
        path: "batch-profile-adjustment-log",
      },
      {
        name: "Daily Performance Adjustment Log",
        path: "daily-performance-adjustment-log",
      },
      {
        name: "Daily Production Adjustment Log",
        path: "daily-production-adjustment-log",
      },
      {
        name: "Employee Detail Adjustment Log",
        path: "employee-detail-adjustment-log",
      },
      {
        name: "Managers Performance Adjustment Log",
        path: "managers-performance-adjustment-log",
      },
    ],
  },
  {
    name: "PIMS",
    children: [
      {
        name: "Closeout",
        path: "closeout",
      },
      {
        name: "Estimates",
        path: "estimates",
      },
      {
        name: "Maintenance",
        path: "maintenance",
      },
    ],
  },
  {
    name: "Reports",
    children: [
      {
        name: "Batch Query",
        path: "batch-query",
      },
      {
        name: "Inventory Report",
        path: "inventory-report",
      },
      {
        name: "Late Cycle Report",
        path: "late-cycle-report",
      },
      {
        name: "Production Report",
        path: "production-report",
      },
      {
        name: "Quarterly Scheduled Data Report",
        path: "quarterly-scheduled-data-report",
      },
      {
        name: "Receipts Report",
        path: "receipts-report",
      },
      {
        name: "Re-Print Transmittals",
        path: "re-print-transmittals",
      },
      {
        name: "Sorted MCR Report",
        path: "sorted-mcr-report",
      },
    ],
  },
];

export default navLinks;
