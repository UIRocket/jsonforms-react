import axios from "axios";

let baseUrl = axios.create({
    baseURL: 'https://###/',
})

export default baseUrl