import React, { useState } from "react";
import {
  AppBar,
  Toolbar,
  Typography,
  Container,
  Button,
} from "@mui/material";
import AcUnitIcon from "@mui/icons-material/AcUnit";
import LoginIcon from "@mui/icons-material/Login";
import GroupAddIcon from "@mui/icons-material/GroupAdd";

const Header = () => {
  const [anchorElUser, setAnchorElUser] = useState(null);

  return (
    <AppBar position="static">
      <Container maxWidth="xl">
        <Toolbar>
          {/* Desktop Logo & Name */}
          <AcUnitIcon sx={{ display: { xs: "none", md: "flex" }, mr: 1 }} />

          <Typography
            variant="h6"
            noWrap
            component="a"
            href="/"
            sx={{
              mr: 2,
              display: { xs: "none", md: "flex" },
              fontFamily: "monospace",
              fontWeight: 700,
              letterSpacing: ".3rem",
              color: "inherit",
              textDecoration: "none",
            }}
          >
            BBTS
          </Typography>

          {/* Mobile Logo & Name */}
          <AcUnitIcon sx={{ display: { xs: "flex", md: "none" }, mr: 1 }} />

          <Typography
            variant="h5"
            noWrap
            component="a"
            href=""
            sx={{
              mr: 2,
              display: { xs: "flex", md: "none" },
              flexGrow: 1,
              fontFamily: "monospace",
              fontWeight: 700,
              letterSpacing: ".3rem",
              color: "inherit",
              textDecoration: "none",
            }}
          >
            BBTS
          </Typography>

            <>
              <Button
                variant="contained"
                href="/signup"
                startIcon={<GroupAddIcon />}
                sx={{
                  marginLeft: "auto",
                  backgroundColor: "#fff",
                  color: "#1976D2",
                  ":hover": {
                    bgcolor: "white",
                    color: "#000",
                  },
                }}
              >
                Sign Up
              </Button>
              
              <Button
                variant="contained"
                href="/login"
                startIcon={<LoginIcon />}
                sx={{
                  marginLeft: "10px",
                  backgroundColor: "#fff",
                  color: "#1976D2",
                  ":hover": {
                    bgcolor: "white",
                    color: "#000",
                  },
                }}
              >
                Login
              </Button>
            </>
        </Toolbar>
      </Container>
    </AppBar>
  );
};

export default Header;
