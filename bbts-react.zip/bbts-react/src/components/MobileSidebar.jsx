import React, { useState } from "react";
import Routers from "../routers/Routers";
import profile from "../data/images/profile.png";
import MenuIcon from "@mui/icons-material/Menu";
import AcUnitIcon from "@mui/icons-material/AcUnit";
import {
  AppBar,
  Box,
  Toolbar,
  IconButton,
  Typography,
  Menu,
  Avatar,
  Tooltip,
  MenuItem,
  CssBaseline,
  Divider,
  Drawer,
  List,
  Container,
  Button,
  Link,
  Collapse,
  ListItem,
  ListItemText,
  ListItemButton,
} from "@mui/material";
import SidebarCollapseItem from "./SidebarCollapseItem";
import Breadcrumb from "./Breadcrumb";
import navLinks from "../data/navLinks";
import menuPages from "../data/menuPage";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";

// user setting options
const settings = ["Profile", "Account", "Dashboard", "Logout"];

const drawerWidth = 300;

function MobileSidebar(props) {
  const { window } = props;
  const [mobileOpen, setMobileOpen] = useState(false);
  const [anchorElUser, setAnchorElUser] = useState(null);
  const [anchorElNav, setAnchorElNav] = useState(null);
  const [menuDropdown, setMenuDropdown] = useState(null);

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };

  const drawer = (
    <div>
      <Toolbar />
      <Divider />
      <List>
        {navLinks.map((item, index) => (
          <SidebarCollapseItem item={item} closeMobileNav={setMobileOpen}/>
        ))}
      </List>
    </div>
  );

  const container =
    window !== undefined ? () => window().document.body : undefined;

  return (
    <Box sx={{ display: { xs: "flex", sm: "none" } }}>
      <CssBaseline />

      {/* Header */}
      <AppBar
        position="fixed"
        elevation={0}
        sx={{
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          ml: { sm: `${drawerWidth}px` },
          // background: "linear-gradient(to right, #2a042b, #f4d3f5)",
          borderBottom: "1px solid #7e7e7e",
        }}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2, display: { sm: "none" } }}
          >
            <MenuIcon />
          </IconButton>

          {/* Mobile Logo & Name */}
          <AcUnitIcon sx={{ display: { xs: "flex", md: "none" }, mr: 1 }} />

          <Typography
            variant="h5"
            noWrap
            component="a"
            href=""
            sx={{
              mr: 2,
              display: { xs: "flex", md: "none" },
              flexGrow: 1,
              fontFamily: "monospace",
              fontWeight: 700,
              letterSpacing: ".3rem",
              color: "inherit",
              textDecoration: "none",
            }}
          >
            BBTS
          </Typography>

          {/* User Settings */}
          <>
            <Box sx={{ flexGrow: 0, marginLeft: "auto" }}>
              <Tooltip title="Open settings">
                <IconButton onClick={handleOpenUserMenu} sx={{ p: 0 }}>
                  <Avatar alt="Remy Sharp" src={profile} />
                </IconButton>
              </Tooltip>
              <Menu
                sx={{ mt: "45px" }}
                id="menu-appbar"
                anchorEl={anchorElUser}
                anchorOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                keepMounted
                transformOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                open={Boolean(anchorElUser)}
                onClose={handleCloseUserMenu}
              >
                {settings.map((setting) => (
                  <MenuItem key={setting} onClick={handleCloseUserMenu}>
                    <Typography textAlign="center">{setting}</Typography>
                  </MenuItem>
                ))}
              </Menu>
            </Box>
          </>
        </Toolbar>
      </AppBar>

      {/* Sub-header */}
      <AppBar
        elevation={0}
        sx={{
          borderBottom: "1px solid #7e7e7e",
          position: "absolute",
          top: 0,
          zIndex: 1,
        }}
      >
        <Container maxWidth="xl" disableGutters>
          <Toolbar />
          <Toolbar>
            {/* Mobile Menu Links */}
            <Box sx={{ flexGrow: 1, display: { xs: "flex", md: "none" } }}>
              <IconButton
                size="large"
                aria-label="account of current user"
                aria-controls="menu-appbar"
                aria-haspopup="true"
                onClick={handleOpenNavMenu}
                color="inherit"
              >
                <MenuIcon />
              </IconButton>
              <Menu
                id="menu-appbar"
                anchorEl={anchorElNav}
                anchorOrigin={{
                  vertical: "bottom",
                  horizontal: "left",
                }}
                keepMounted
                transformOrigin={{
                  vertical: "top",
                  horizontal: "left",
                }}
                open={Boolean(anchorElNav)}
                onClose={handleCloseNavMenu}
                sx={{
                  display: { xs: "block", md: "none" },
                }}
              >
                {menuPages.map((item) => (
                  <MenuItem
                    key={item.name}
                    // onClick={handleCloseNavMenu}
                    sx={{ width: "300px" }}
                  >
                    {item.children ? (
                      <div style={{display: "block"}}>
                        <Button
                          key={item.name}
                          sx={{
                            my: 0,
                            mx: 0,
                            padding: 0,
                            display: "flex",
                            alignItems: "flex-start",
                            justifyContent: "space-between",
                            color: "#000",
                          }}
                        >
                          <Link
                            style={{
                              color: "#000",
                              textDecoration: "none",
                              cursor: "pointer",
                            }}
                            onClick={() => setMenuDropdown(!menuDropdown)}
                          >
                            {item.name}
                          </Link>
                          {menuDropdown ? (
                            <ExpandLessIcon />
                          ) : (
                            <ExpandMoreIcon />
                          )}
                        </Button>
                        <Collapse
                          in={menuDropdown}
                          timeout="auto"
                          sx={{
                            width: "270px",
                            margin: "auto",
                          }}
                        >
                          <List sx={{ marginLeft: 1 }}>
                            {item.children?.map((item, index) => {
                              return (
                                <ListItem
                                  key={index}
                                  disablePadding
                                  component={Link}
                                  to={item.path}
                                  sx={{ color: "#003cff" }}
                                  onClick={handleCloseNavMenu}
                                >
                                  <ListItemButton>
                                    <ListItemText primary={item.name} />
                                  </ListItemButton>
                                </ListItem>
                              );
                            })}
                          </List>
                        </Collapse>
                      </div>
                    ) : (
                      <Link
                        href={item.path}
                        sx={{ color: "#000", textDecoration: "none" }}
                      >
                        {item.name}
                      </Link>
                    )}
                  </MenuItem>
                ))}
              </Menu>
            </Box>
          </Toolbar>
        </Container>
      </AppBar>

      {/* Sidebar */}
      <Box
        component="nav"
        sx={{ width: { sm: drawerWidth }, flexShrink: { sm: 0 } }}
        aria-label="mailbox folders"
      >
        {/* Mobile Sidebar */}
        <Drawer
          container={container}
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{
            keepMounted: true,
          }}
          sx={{
            display: { xs: "block", sm: "none" },
            "& .MuiDrawer-paper": {
              boxSizing: "border-box",
              width: drawerWidth,
            },
          }}
        >
          {drawer}
        </Drawer>
      </Box>

      {/* Routes */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: 3,
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          mt: 15,
        }}
      >
        {/* <Toolbar /> */}
        <>
          <Breadcrumb />
          <Routers />
        </>
      </Box>
    </Box>
  );
}

export default MobileSidebar;
