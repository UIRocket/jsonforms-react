import { withJsonFormsControlProps } from '@jsonforms/react';
import DependentSelectBoxes from './DependentSelectBoxes';

const DependentSelectBoxControl = ({ schema, data, handleChange, path }) => (
  <DependentSelectBoxes
    data={data}
    changeValue={(newValue) => handleChange(path, newValue)}
    schema={schema}
  />
);

export default withJsonFormsControlProps(DependentSelectBoxControl);