import './dependentSelectBoxes.css'
import React, { useState } from "react";
import { Select, MenuItem, FormControl, InputLabel } from "@mui/material";
import axios from "axios";

const selectBoxOptions = [
  {
    label: "Option 1",
    value: "option-1",
  },
  {
    label: "Option 2",
    value: "option-2",
  },
  {
    label: "Option 3",
    value: "option-3",
  },
];

const DependentSelectBoxes = ({ data, changeValue, schema }) => {
  const [firstSelectValue, setFirstSelectValue] = useState(data ?? "");
  const [secondSelectValue, setSecondSelectValue] = useState("");
  const [secondSelectOptions, setSecondSelectOptions] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleFirstSelectChange = async (event) => {
    console.log("handleFirstSelectChange Called");
    const value = event.target.value;
    setFirstSelectValue(value);
    changeValue(value);

    // Fetch options for the second select box
    try {
      setIsLoading(true);
      // const response = await axios.get(
      //   `https://api.example.com/options/${value}`
      // );
      setSecondSelectOptions(selectBoxOptions);
      setSecondSelectValue("");
    } catch (error) {
      console.error("Error fetching options for the second select box:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSecondSelectChange = (event) => {
    setSecondSelectValue(event.target.value);
  };

  return (
    <div
      style={
        {
          // flexBasis: "auto",
          // display: "flex",
          // position: "unset",
          // width: "calc(100%)",
          // flexWrape: "wrap"
        }
      }
    >
      <div variant="standard" style={{paddingTop: "0"}} className="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-true css-1vd824g-MuiGrid-root">
        <FormControl fullWidth>
          <InputLabel id="first-select">{schema.label}</InputLabel>
          <Select
            labelId="first-select"
            id="first-select"
            value={firstSelectValue}
            onChange={handleFirstSelectChange}
          >
            {schema.enum.map((option) => (
              <MenuItem
                key={option.toLowerCase().replace(" ", "-")}
                value={option.toLowerCase().replace(" ", "-")}
              >
                {option}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </div>

      <div variant="standard" style={{paddingTop: "16px"}} className="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-true css-1vd824g-MuiGrid-root">
        <FormControl fullWidth >
          <InputLabel id="second-select">Second Select Box</InputLabel>
          <Select
            labelId="second-select"
            id="second-select"
            value={secondSelectValue}
            disabled={!firstSelectValue}
            onChange={handleSecondSelectChange}
          >
            {isLoading ? (
              <MenuItem value="">Loading...</MenuItem>
            ) : (
              secondSelectOptions.map((option) => (
                <MenuItem key={option.value} value={option.value}>
                  {option.label}
                </MenuItem>
              ))
            )}
          </Select>
        </FormControl>
      </div>
    </div>
  );
};

export default DependentSelectBoxes;
