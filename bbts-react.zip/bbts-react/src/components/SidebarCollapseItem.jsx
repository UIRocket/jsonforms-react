import React, { useState } from "react";
import { Link } from "react-router-dom";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import {
  Collapse,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
} from "@mui/material";
import { isContentEditable } from "@testing-library/user-event/dist/utils";

let GrandChildFunc = ({ item, closeMobileNav }) => {
  const [grandChildOpen, setGrandChildOpen] = useState(false);
  const [childOpen, setChildOpen] = useState(false);
  return (
    <>
      <ListItem
        key={item.name}
        disablePadding
        sx={{ color: "#262426" }}
        onClick={() => {
          setGrandChildOpen(!grandChildOpen);
        }}
      >
        <ListItemButton>
          <ListItemText primary={item.name} />
          {item.children ? (
            grandChildOpen ? (
              <ExpandLessIcon />
            ) : (
              <ExpandMoreIcon />
            )
          ) : (
            ""
          )}
        </ListItemButton>
      </ListItem>

      {/* children Dropdown */}
      {item.children ? (
        <Collapse
          in={grandChildOpen}
          timeout="auto"
          sx={{
            borderBottom: "2px solid #b3b1ad",
            boxShadow: "0 1px 1px 0 #7e7e7e",
            width: "90%",
            margin: "auto",
            borderRadius: "5px",
          }}
        >
          <List sx={{ marginLeft: 1 }}>
            {item.children?.map((item, index) => {
              return (
                <ListItem
                  key={index}
                  disablePadding
                  component={Link}
                  to={item.path}
                  sx={{ color: "#003cff" }}
                  onClick={() => {
                    closeMobileNav(false);
                    setChildOpen(!childOpen);
                  }}
                >
                  <ListItemButton>
                    <ListItemText primary={item.name} />
                  </ListItemButton>
                </ListItem>
              );
            })}
          </List>
        </Collapse>
      ) : (
        ""
      )}
    </>
  );
};

let DirectChildFunc = ({ item, closeMobileNav }) => {
  const [directChildOpen, setDirectChildOpen] = useState(false);
  return (
    <>
      <ListItem
        key={item.name}
        disablePadding
        sx={{ color: "#262426" }}
        onClick={() => {
          setDirectChildOpen(!directChildOpen);
        }}
      >
        <ListItemButton>
          <ListItemText primary={item.name} />
          {directChildOpen ? <ExpandLessIcon /> : <ExpandMoreIcon />}
        </ListItemButton>
      </ListItem>

      {/* Grand children Dropdown */}
      <Collapse
        in={directChildOpen}
        timeout="auto"
        sx={{
          borderBottom: "2px solid #b3b1ad",
          boxShadow: "0 1px 1px 0 #7e7e7e",
          width: "90%",
          margin: "auto",
          borderRadius: "5px",
        }}
      >
        <List sx={{ marginLeft: 1 }}>
          {item.grandChildren?.map((item) => (
            <GrandChildFunc item={item} closeMobileNav={closeMobileNav} />
          ))}
        </List>
      </Collapse>
    </>
  );
};

const SidebarCollapseItem = ({ item, closeMobileNav }) => {
  const [open, setOpen] = useState(false);

  return (
    <>
      <ListItem
        key={item.name}
        disablePadding
        sx={{ color: "#262426" }}
        onClick={() => {
          setOpen(!open);
        }}
      >
        <ListItemButton>
          <ListItemText primary={item.name} />
          <ListItemIcon>
            {open ? <ExpandLessIcon /> : <ExpandMoreIcon />}
          </ListItemIcon>
        </ListItemButton>
      </ListItem>

      {/* Direct children Dropdown */}
      <Collapse
        in={open}
        timeout="auto"
        sx={{
          borderBottom: "2px solid #b3b1ad",
          boxShadow: "0 1px 1px 0 #7e7e7e",
          width: "90%",
          margin: "auto",
          borderRadius: "5px",
        }}
      >
        <List sx={{ marginLeft: 1 }}>
          {item.directChildren
            ? item.directChildren.map((item) => (
                <DirectChildFunc item={item} closeMobileNav={closeMobileNav} />
              ))
            : item.grandChildren
            ? item.grandChildren.map((item) => (
                <GrandChildFunc item={item} closeMobileNav={closeMobileNav} />
              ))
            : item.children
            ? item.children.map((item) => (
                <ListItem
                  key={item.name}
                  disablePadding
                  component={Link}
                  to={item.path}
                  sx={{ color: "#003cff" }}
                  onClick={() => {
                    closeMobileNav(false);
                  }}
                >
                  <ListItemButton>
                    <ListItemText primary={item.name} />
                  </ListItemButton>
                </ListItem>
              ))
            : ""}
        </List>
      </Collapse>
    </>
  );
};

export default SidebarCollapseItem;
