import React, {  useState } from "react";
import "./sidebar.css";
import { styled, useTheme } from "@mui/material/styles";
import MuiAppBar from "@mui/material/AppBar";
import MenuIcon from "@mui/icons-material/Menu";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import AcUnitIcon from "@mui/icons-material/AcUnit";
import profile from "../data/images/profile.png";
import {
  Box,
  Drawer,
  CssBaseline,
  Toolbar,
  List,
  Typography,
  Divider,
  IconButton,
  Avatar,
  Tooltip,
  MenuItem,
  Menu,
  Container,
  Button,
  Link,
} from "@mui/material";
import navLinks from "../data/navLinks";
import SidebarCollapseItem from "./SidebarCollapseItem";
import Breadcrumb from "./Breadcrumb";
import Routers from "../routers/Routers";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import menuPages from "../data/menuPage";

const drawerWidth = 300;

const Main = styled("main", { shouldForwardProp: (prop) => prop !== "open" })(
  ({ theme, open }) => ({
    flexGrow: 1,
    padding: theme.spacing(3),
    transition: theme.transitions.create("margin", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    marginLeft: `-${drawerWidth}px`,
    ...(open && {
      transition: theme.transitions.create("margin", {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen,
      }),
      marginLeft: 0,
    }),
  })
);

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  transition: theme.transitions.create(["margin", "width"], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    width: `calc(100% - ${drawerWidth}px)`,
    marginLeft: `${drawerWidth}px`,
    transition: theme.transitions.create(["margin", "width"], {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

const DrawerHeader = styled("div")(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  padding: theme.spacing(0, 1),
  // necessary for content to be below app bar
  ...theme.mixins.toolbar,
  justifyContent: "flex-end",
}));

// user setting options
const settings = ["Profile", "Account", "Dashboard", "Logout"];

function Sidebar() {
  const theme = useTheme();
  const [open, setOpen] = useState(true);
  const [anchorElUser, setAnchorElUser] = useState(null);
  const [anchorElNav, setAnchorElNav] = useState(null);
  const [menuDropdown, setMenuDropdown] = useState(null);
  const [mobile, setMobile] = useState(null);

  // Menu Dropdown
  const handleMenu = (event) => {
    setMenuDropdown(event.currentTarget);
  };

  const handleClose = () => {
    setMenuDropdown(null);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };

  // User Settings Menu
  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };

  return (
    <Box sx={{ display: { xs: "none", sm: "flex" } }}>
      <CssBaseline />

      {/* Header */}
      <AppBar
        position="fixed"
        elevation={0}
        open={open}
        sx={{
          borderBottom: "1px solid #7e7e7e",
          zIndex: 2,
        }}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            onClick={handleDrawerOpen}
            edge="start"
            sx={{
              mr: 2,
              ...(open && { display: "none" }),
            }}
          >
            <MenuIcon />
          </IconButton>

          {/* Desktop Logo & Name */}
          <AcUnitIcon sx={{ display: { xs: "none", md: "flex" }, mr: 1 }} />

          <Typography
            variant="h6"
            noWrap
            component="a"
            href="/"
            sx={{
              mr: 2,
              display: { xs: "none", md: "flex" },
              fontFamily: "monospace",
              fontWeight: 700,
              letterSpacing: ".3rem",
              color: "inherit",
              textDecoration: "none",
            }}
          >
            BBTS
          </Typography>

          {/* User Settings */}
          <>
            <Box sx={{ flexGrow: 0, marginLeft: "auto" }}>
              <Tooltip title="Open settings">
                <IconButton onClick={handleOpenUserMenu} sx={{ p: 0 }}>
                  <Avatar alt="Remy Sharp" src={profile} />
                </IconButton>
              </Tooltip>
              <Menu
                sx={{ mt: "45px" }}
                id="menu-appbar"
                anchorEl={anchorElUser}
                anchorOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                keepMounted
                transformOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                open={Boolean(anchorElUser)}
                onClose={handleCloseUserMenu}
              >
                {settings.map((setting) => (
                  <MenuItem key={setting} onClick={handleCloseUserMenu}>
                    <Typography textAlign="center">{setting}</Typography>
                  </MenuItem>
                ))}
              </Menu>
            </Box>
          </>
        </Toolbar>
      </AppBar>

      {/* Sub-header */}
      <AppBar
        elevation={0}
        open={open}
        sx={{
          borderBottom: "1px solid #7e7e7e",
          position: "absolute",
          top: 0,
          zIndex: 1,
        }}
      >
        <Container maxWidth="xl" disableGutters>
          <Toolbar />
          <Toolbar>
            {/* Desktop Menu Links */}
            <Box
              sx={{
                flexGrow: 1,
                display: { xs: "none", md: "flex" },
                alignItems: "flex-end",
              }}
            >
              {menuPages.map((item) =>
                item.children ? (
                  <>
                    <Button
                      key={item.name}
                      sx={{
                        my: 0,
                        display: "flex",
                        alignItems: "center",
                        color: "#fff",
                      }}
                    >
                      <Link
                        style={{
                          color: "white",
                          textDecoration: "none",
                          cursor: "pointer",
                        }}
                        id="dropdownMenuButton"
                        aria-controls="dropdown-menu"
                        aria-haspopup="true"
                        onClick={handleMenu}
                      >
                        {item.name}
                      </Link>
                      {menuDropdown ? <ExpandLessIcon /> : <ExpandMoreIcon />}
                    </Button>
                    <Menu
                      id="dropdown-menu"
                      anchorEl={menuDropdown}
                      open={Boolean(menuDropdown)}
                      onClose={handleClose}
                      MenuListProps={{
                        "aria-labelledby": "dropdownMenuButton",
                      }}
                    >
                      {item.children.map((item) => (
                        <MenuItem
                          onClick={handleClose}
                          sx={{
                            width: "200px",
                            borderBottom: "1px solid #e5e5e5",
                          }}
                        >
                          <Link
                            href={item.path}
                            style={{ color: "inherit", textDecoration: "none" }}
                          >
                            {item.name}
                          </Link>
                        </MenuItem>
                      ))}
                    </Menu>
                  </>
                ) : (
                  <Button
                    key={item.name}
                    onClick={handleCloseNavMenu}
                    sx={{ my: 0, display: "block" }}
                  >
                    <Link
                      href={item.path}
                      sx={{ color: "white", textDecoration: "none" }}
                      onClick={handleCloseNavMenu}
                    >
                      {item.name}
                    </Link>
                  </Button>
                )
              )}
            </Box>
          </Toolbar>
        </Container>
      </AppBar>

      {/* Desktop Sidebar */}
      <Drawer
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          "& .MuiDrawer-paper": {
            width: drawerWidth,
            boxSizing: "border-box",
          },
        }}
        variant="persistent"
        anchor="left"
        open={open}
      >
        <DrawerHeader>
          <IconButton onClick={handleDrawerClose}>
            {theme.direction === "ltr" ? (
              <ChevronLeftIcon />
            ) : (
              <ChevronRightIcon />
            )}
          </IconButton>
        </DrawerHeader>

        <Divider />

        <List>
          {navLinks.map((item, index) => (
            <SidebarCollapseItem key={item.name} item={item} closeMobileNav={setMobile}/>
          ))}
        </List>
      </Drawer>

      {/* Routes */}
      <Main open={open} sx={{ mt: 15, zIndex: 1 }}>
        <>
          <Breadcrumb />
          <Divider />
          <Routers />
        </>
      </Main>
    </Box>
  );
}

export default Sidebar;
