import React, { useEffect } from "react";
import Sidebar from "./Sidebar";
import Signup from "../pages/Signup";
import Header from "./Header";
import { useDispatch, useSelector } from "react-redux";
import { fecthAsyncUsers } from "../store/userSlice";
import MobileSidebar from "./MobileSidebar";

const Layout = () => {
  const dispatch = useDispatch();
  const user = useSelector((state) => state.userReducer.user);

  useEffect(() => {
    dispatch(fecthAsyncUsers());
  }, [dispatch]);

  return (
    <>
      {user === true ? (
        <>
          <Sidebar />
          <MobileSidebar />
        </>
      ) : (
        <>
          <Header />
          <Signup />
        </>
      )}
    </>
  );
};

export default Layout;
