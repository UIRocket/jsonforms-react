import "./form.css";
import { materialCells } from "@jsonforms/material-renderers";
import { JsonForms } from "@jsonforms/react";
import { Button } from "@mui/material";
import React, { useState } from "react";

const Form = ({ schema, uischema, initialData, renderers }) => {
  const [formData, setFormData] = useState(initialData);
  const [validationErrors, setValidationErrors] = useState([]);
  const [validationMode, setValidationMode] = useState("ValidateAndHide");

  const handleChange = ({ data, errors }) => {
    console.log("Data:", data);
    setFormData(data);
    setValidationErrors(errors);
  };

  const handleSubmit = () => {
    if (validationErrors.length === 0) {
      // Perform your API submission using formData
      console.log("Submitting data:", formData);
      setFormData(initialData)
      setValidationMode("ValidateAndHide")
      setValidationErrors([])
    } else {
      setValidationMode("ValidateAndShow");
      console.log("Validation failed");
    }
  };

  return (
    <>
      <JsonForms
        schema={schema}
        uischema={uischema}
        data={formData}
        renderers={renderers}
        cells={materialCells}
        validationMode={validationMode}
        onChange={handleChange}
      />
      <Button onClick={() => setFormData({})} color="primary">
        Clear form data
      </Button>
      <Button onClick={handleSubmit} sx={{ marginLeft: "auto" }}>
        Submit
      </Button>
    </>
  );
};

export default Form;
