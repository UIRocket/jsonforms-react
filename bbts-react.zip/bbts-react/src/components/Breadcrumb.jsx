import React from "react";
import { useLocation, Link } from "react-router-dom";

const Breadcrumb = () => {
  const location = useLocation();
  const paths = location.pathname.split("/").filter((path) => path !== "");

  return (
    <nav aria-label="breadcrumb" style={{margin: "5px 0 3px 0"}}>
      <span className="breadcrumb-item">
        {location.pathname !== "/" ? (
          <Link
            to="/"
            style={{
              textDecoration: "none",
              fontWeight: 500,
              cursor: "pointer"
            }}
          >
            Home
          </Link>
        ) : (
          ""
        )}
      </span>
      {paths.map((path, index) => (
        <span
          key={path}
          className={`breadcrumb-item ${
            index === paths.length - 1 ? "active" : ""
          }`}
          aria-current={index === paths.length - 1 ? "page" : undefined}
        >
          <Link
            to={`/${paths.slice(0, index + 1).join("/")}`}
            style={{
              textDecoration: "none",
              fontWeight: 500,
              cursor: "pointer"
            }}
          >
            {" "}
            <span> / {path}</span>
          </Link>
        </span>
      ))}
    </nav>
  );
};

export default Breadcrumb;
