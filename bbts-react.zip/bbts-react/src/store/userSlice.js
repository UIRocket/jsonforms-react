import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

export const fecthAsyncUsers = createAsyncThunk(
  "users/fecthAsyncUsers",
  async () => {
    // api call here

    let isLogged = true;
    return isLogged;
  }
);

let initialState = {
  user: {},
};

const userSlice = createSlice({
  name: "users ",
  initialState,
  reducers: {},
  extraReducers: {
    [fecthAsyncUsers.pending]: () => {
      console.log("Pending")
    },
    [fecthAsyncUsers.fulfilled]: (state, { payload }) => {
      console.log("FulFilled");
      return { ...state, user: payload, isLoading: false };
    },
    [fecthAsyncUsers.rejected]: () => {
        console.log("Rejected");
    },
  },
});

export default userSlice.reducer;
