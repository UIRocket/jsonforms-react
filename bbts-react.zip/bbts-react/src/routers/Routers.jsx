import React, { useEffect } from "react";
import { Route, Routes } from "react-router-dom";
import DlnGeneration from "../pages/DlnGeneration";
import Login from "../pages/Login";
import Signup from "../pages/Signup";
import Welcome from "../pages/Welcome";
import BatchCreation from "../pages/BatchCreation";
import VolumeChange from "../pages/VolumeChange";
import { useDispatch, useSelector } from "react-redux";
import { fecthAsyncUsers } from "../store/userSlice";
import NoMatch from "../pages/NoMatch";

const Routers = () => {
  const dispatch = useDispatch();
  const user = useSelector((state) => state.userReducer.user);

  useEffect(() => {
    dispatch(fecthAsyncUsers());
  }, [dispatch]);

  return (
    <>
      {user === true ? (
        <Routes>
          <Route path="/" element={<Welcome />} />
          <Route path="batch-creation" element={<BatchCreation />} />
          <Route path="volume-change" element={<VolumeChange />} />
          <Route path="dln-generation" element={<DlnGeneration />} />
          <Route path="*" element={<NoMatch />} />
        </Routes>
      ) : (
        <Routes>
          <Route path="login" element={<Login />} />
          <Route path="signup" element={<Signup />} />
          <Route path="*" element={<NoMatch />} />
        </Routes>
      )}
    </>
  );
};

export default Routers;
