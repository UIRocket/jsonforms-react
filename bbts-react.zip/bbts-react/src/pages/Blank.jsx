import React from "react";

const Blank = () => {
  return (
    <>
    <h2>Blank page</h2>
    </>
  );
};

export default Blank;
