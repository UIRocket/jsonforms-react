import React from "react";
import schema from "../schema/Batch Creation/schema.json";
import uischema from "../schema/Batch Creation/uischema.json";
import initialData from "../schema/Batch Creation/initialData.json";
import Form from "../components/Form";
import { materialRenderers } from "@jsonforms/material-renderers";
import dependentSelectBoxControlTester from "../components/renderer/dependentSelectBoxControlTester";
import DependentSelectBoxControl from "../components/renderer/DependentSelectBoxControl";

const renderers = [
  ...materialRenderers,
  {
    tester: dependentSelectBoxControlTester,
    renderer: DependentSelectBoxControl,
  },
];

const BatchCreation = () => { 

  return (
    <>
      <Form schema={schema} uischema={uischema} initialData={initialData} renderers={renderers} />
    </>
  );
};  

export default BatchCreation;
