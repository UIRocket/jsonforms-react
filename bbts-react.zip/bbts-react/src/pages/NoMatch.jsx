import React from "react";
import { Link } from "react-router-dom";

const NoMatch = () => {
  return (
    <div>
      <h2>Page Does not exist</h2>
      <Link to={"/"}>Go Back To Home Page</Link>
    </div>
  );
};

export default NoMatch;
