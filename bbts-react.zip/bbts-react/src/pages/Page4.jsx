import React from "react";
import Form from "../components/Form";
import schema from '../schema/DLN Generation/schema.json'
import uischema from '../schema/DLN Generation/uischema.json'
import initialData from '../schema/DLN Generation/initialData.json'
import { materialRenderers } from "@jsonforms/material-renderers";

const Page4 = () => {
  return (
    <Form schema={schema} uischema={uischema} initialData={initialData} renderers={materialRenderers} />
  );
};

export default Page4;
