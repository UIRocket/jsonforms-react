import React from 'react'
import Form from '../components/Form'
import schema from "../schema/Batch Block Volume Change/schema.json";
import uischema from "../schema/Batch Block Volume Change/uischema.json";
import initialData from "../schema/Batch Block Volume Change/initialData.json";
import { materialRenderers } from '@jsonforms/material-renderers';
import dependentSelectBoxControlTester from '../components/renderer/dependentSelectBoxControlTester';
import DependentSelectBoxControl from '../components/renderer/DependentSelectBoxControl';

const renderers = [
  ...materialRenderers,
  {
    tester: dependentSelectBoxControlTester,
    renderer: DependentSelectBoxControl,
  },
];

const VolumeChange = () => {
  return (
    <>
      <Form schema={schema} uischema={uischema} initialData={initialData} renderers={renderers}/>
    </>
  )
}

export default VolumeChange