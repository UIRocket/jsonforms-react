import React from "react";

const Welcome = () => {
  return (
    <>
      <h1>Welcome,</h1>
      <h3>You can naviagte to your desired forms</h3>
    </>
  );
};

export default Welcome;
